import React, { createContext, useContext, useState } from 'react';

type LanguageContextType = {
  language: 'pl' | 'en';
  setLanguage: (lang: 'pl' | 'en') => void;
  t: (key: string) => string;
};

const translations = {
  pl: {
    'nav.home': 'Strona Główna',
    'nav.about': 'O Nas',
    'nav.portfolio': 'Portfolio',
    'nav.services': 'Usługi',
    'nav.contact': 'Kontakt',
    
    'hero.title': 'Projektowanie i Aranżacje Wnętrz\nWizualizacje',
    'hero.subtitle': 'Profesjonalne projekty wnętrz, które łączą funkcjonalność z estetyką. Przekształcamy marzenia w rzeczywistość.',
    'hero.cta': 'Umów Konsultację',
    
    'services.title': 'Nasze Usługi',
    'services.subtitle': 'Oferujemy kompleksowe rozwiązania w zakresie projektowania wnętrz',
    'services.interior': 'Projekty Wnętrz',
    'services.interior.desc': 'Kompleksowe projekty dostosowane do Twoich potrzeb i stylu życia.',
    'services.commercial': 'Projekty Komercyjne',
    'services.commercial.desc': 'Funkcjonalne przestrzenie biznesowe, biura, restauracje i hotele.',
    'services.furniture': 'Dobór Wyposażenia',
    'services.furniture.desc': 'Pomoc w wyborze mebli, materiałów i dodatków do Twojego wnętrza.',
    'services.visualization': 'Wizualizacje 3D',
    'services.visualization.desc': 'Fotorealistyczne wizualizacje pozwalające zobaczyć efekt końcowy.',
    
    'portfolio.title': 'Nasze Realizacje',
    'portfolio.subtitle': 'Zobacz nasze wybrane projekty w różnych kategoriach',
    'portfolio.viewProject': 'Zobacz projekt',
    'portfolio.categories.all': 'Wszystkie',
    'portfolio.categories.kitchen': 'Kuchnia',
    'portfolio.categories.bathroom': 'Łazienka',
    'portfolio.categories.living': 'Salon',
    'portfolio.categories.bedroom': 'Sypialnia',
    
    'portfolio.location.szczecin': 'Szczecin, Polska',
    
    'portfolio.projects.kitchen1.title': 'Kuchnia Pogodno',
    'portfolio.projects.kitchen1.description': 'Nowoczesna kuchnia z wyspą w apartamencie na Pogodnie',
    
    'portfolio.projects.kitchen2.title': 'Kuchnia Warszewo',
    'portfolio.projects.kitchen2.description': 'Elegancka kuchnia w domu jednorodzinnym na Warszewie',
    
    'portfolio.projects.bathroom1.title': 'Łazienka Centrum',
    'portfolio.projects.bathroom1.description': 'Minimalistyczna łazienka w apartamencie w centrum Szczecina',
    
    'portfolio.projects.bathroom2.title': 'Łazienka Gumieńce',
    'portfolio.projects.bathroom2.description': 'Nowoczesna łazienka z elementami spa na Gumieńcach',
    
    'portfolio.projects.living1.title': 'Salon Bezrzecze',
    'portfolio.projects.living1.description': 'Przestronny salon w domu jednorodzinnym na Bezrzeczu',
    
    'portfolio.projects.living2.title': 'Salon Śródmieście',
    'portfolio.projects.living2.description': 'Elegancki salon w kamienicy w Śródmieściu',
    
    'portfolio.projects.bedroom1.title': 'Sypialnia Niebuszewo',
    'portfolio.projects.bedroom1.description': 'Przytulna sypialnia w apartamencie na Niebuszewie',
    
    'portfolio.projects.bedroom2.title': 'Sypialnia Żelechowa',
    'portfolio.projects.bedroom2.description': 'Nowoczesna sypialnia z garderobą na Żelechowej',
    
    'contact.title': 'Kontakt',
    'contact.subtitle': 'Skontaktuj się z nami, aby omówić Twój projekt',
    'contact.name': 'Imię i Nazwisko',
    'contact.email': 'Email',
    'contact.message': 'Wiadomość',
    'contact.submit': 'Wyślij Wiadomość',
    'contact.phone': 'Telefon',
    'contact.address': 'Obszar działania',
    'contact.area': 'Banie i okolice, woj. zachodniopomorskie',
    'contact.remote': 'Możliwość współpracy zdalnej',
  },
  en: {
    'nav.home': 'Home',
    'nav.about': 'About',
    'nav.portfolio': 'Portfolio',
    'nav.services': 'Services',
    'nav.contact': 'Contact',
    
    'hero.title': 'Interior Design & Arrangement\nVisualizations',
    'hero.subtitle': 'Professional interior design that combines functionality with aesthetics. We transform dreams into reality.',
    'hero.cta': 'Book Consultation',
    
    'services.title': 'Our Services',
    'services.subtitle': 'We offer comprehensive interior design solutions',
    'services.interior': 'Interior Design',
    'services.interior.desc': 'Comprehensive projects tailored to your needs and lifestyle.',
    'services.commercial': 'Commercial Projects',
    'services.commercial.desc': 'Functional business spaces, offices, restaurants, and hotels.',
    'services.furniture': 'Furniture Selection',
    'services.furniture.desc': 'Assistance in choosing furniture, materials, and accessories for your interior.',
    'services.visualization': '3D Visualization',
    'services.visualization.desc': 'Photorealistic visualizations allowing you to see the final result.',
    
    'portfolio.title': 'Our Projects',
    'portfolio.subtitle': 'View our selected projects across different categories',
    'portfolio.viewProject': 'View project',
    'portfolio.categories.all': 'All',
    'portfolio.categories.kitchen': 'Kitchen',
    'portfolio.categories.bathroom': 'Bathroom',
    'portfolio.categories.living': 'Living Room',
    'portfolio.categories.bedroom': 'Bedroom',
    
    'portfolio.location.szczecin': 'Szczecin, Poland',
    
    'portfolio.projects.kitchen1.title': 'Pogodno Kitchen',
    'portfolio.projects.kitchen1.description': 'Modern kitchen with island in Pogodno apartment',
    
    'portfolio.projects.kitchen2.title': 'Warszewo Kitchen',
    'portfolio.projects.kitchen2.description': 'Elegant kitchen in Warszewo single-family house',
    
    'portfolio.projects.bathroom1.title': 'City Center Bathroom',
    'portfolio.projects.bathroom1.description': 'Minimalist bathroom in downtown Szczecin apartment',
    
    'portfolio.projects.bathroom2.title': 'Gumience Bathroom',
    'portfolio.projects.bathroom2.description': 'Modern bathroom with spa elements in Gumience',
    
    'portfolio.projects.living1.title': 'Bezrzecze Living Room',
    'portfolio.projects.living1.description': 'Spacious living room in Bezrzecze single-family house',
    
    'portfolio.projects.living2.title': 'Downtown Living Room',
    'portfolio.projects.living2.description': 'Elegant living room in downtown historic building',
    
    'portfolio.projects.bedroom1.title': 'Niebuszewo Bedroom',
    'portfolio.projects.bedroom1.description': 'Cozy bedroom in Niebuszewo apartment',
    
    'portfolio.projects.bedroom2.title': 'Zelechowa Bedroom',
    'portfolio.projects.bedroom2.description': 'Modern bedroom with walk-in closet in Zelechowa',
    
    'contact.title': 'Contact',
    'contact.subtitle': 'Get in touch with us to discuss your project',
    'contact.name': 'Full Name',
    'contact.email': 'Email',
    'contact.message': 'Message',
    'contact.submit': 'Send Message',
    'contact.phone': 'Phone',
    'contact.address': 'Service Area',
    'contact.area': 'Banie and surroundings, West Pomeranian Voivodeship',
    'contact.remote': 'Remote collaboration available',
  }
};

const LanguageContext = createContext<LanguageContextType | null>(null);

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguage] = useState<'pl' | 'en'>('pl');

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}