import React, { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ArrowRight } from 'lucide-react';

export default function Portfolio() {
  const { t } = useLanguage();
  const [activeCategory, setActiveCategory] = useState('all');

  const categories = [
    { id: 'all', label: t('portfolio.categories.all') },
    { id: 'kitchen', label: t('portfolio.categories.kitchen') },
    { id: 'bathroom', label: t('portfolio.categories.bathroom') },
    { id: 'living', label: t('portfolio.categories.living') },
    { id: 'bedroom', label: t('portfolio.categories.bedroom') }
  ];

  const projects = [
    {
      id: 1,
      title: t('portfolio.projects.kitchen1.title'),
      category: 'kitchen',
      image: 'https://images.unsplash.com/photo-1556911220-bff31c812dba?auto=format&fit=crop&q=80',
      description: t('portfolio.projects.kitchen1.description'),
      area: '35m²',
      year: '2023',
      location: t('portfolio.location.szczecin')
    },
    {
      id: 2,
      title: t('portfolio.projects.kitchen2.title'),
      category: 'kitchen',
      image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?auto=format&fit=crop&q=80',
      description: t('portfolio.projects.kitchen2.description'),
      area: '28m²',
      year: '2023',
      location: t('portfolio.location.szczecin')
    },
    {
      id: 3,
      title: t('portfolio.projects.bathroom1.title'),
      category: 'bathroom',
      image: 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?auto=format&fit=crop&q=80',
      description: t('portfolio.projects.bathroom1.description'),
      area: '12m²',
      year: '2023',
      location: t('portfolio.location.szczecin')
    },
    {
      id: 4,
      title: t('portfolio.projects.bathroom2.title'),
      category: 'bathroom',
      image: 'https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&q=80',
      description: t('portfolio.projects.bathroom2.description'),
      area: '15m²',
      year: '2023',
      location: t('portfolio.location.szczecin')
    },
    {
      id: 5,
      title: t('portfolio.projects.living1.title'),
      category: 'living',
      image: 'https://images.unsplash.com/photo-1600210492493-0946911123ea?auto=format&fit=crop&q=80',
      description: t('portfolio.projects.living1.description'),
      area: '45m²',
      year: '2023',
      location: t('portfolio.location.szczecin')
    },
    {
      id: 6,
      title: t('portfolio.projects.living2.title'),
      category: 'living',
      image: 'https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&q=80',
      description: t('portfolio.projects.living2.description'),
      area: '42m²',
      year: '2023',
      location: t('portfolio.location.szczecin')
    },
    {
      id: 7,
      title: t('portfolio.projects.bedroom1.title'),
      category: 'bedroom',
      image: 'https://images.unsplash.com/photo-1617325247661-675ab4b64ae2?auto=format&fit=crop&q=80',
      description: t('portfolio.projects.bedroom1.description'),
      area: '22m²',
      year: '2023',
      location: t('portfolio.location.szczecin')
    },
    {
      id: 8,
      title: t('portfolio.projects.bedroom2.title'),
      category: 'bedroom',
      image: 'https://images.unsplash.com/photo-1617098900591-3f90928e8c54?auto=format&fit=crop&q=80',
      description: t('portfolio.projects.bedroom2.description'),
      area: '25m²',
      year: '2023',
      location: t('portfolio.location.szczecin')
    }
  ];

  const filteredProjects = projects.filter(
    project => activeCategory === 'all' || project.category === activeCategory
  );

  return (
    <section id="portfolio" className="py-32 bg-white">
      <div className="max-w-[1920px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl font-light text-gray-900 tracking-wide">
            {t('portfolio.title')}
          </h2>
          <p className="mt-6 text-lg text-gray-600 font-light tracking-wide max-w-2xl mx-auto">
            {t('portfolio.subtitle')}
          </p>
          
          <div className="flex flex-wrap justify-center gap-6 mt-12">
            {categories.map(category => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-8 py-3 text-sm font-light tracking-wide transition-all duration-300 ${
                  activeCategory === category.id
                    ? 'bg-gray-900 text-white'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-16 gap-y-20">
          {filteredProjects.map((project) => (
            <div key={project.id} className="group">
              <a href="#" className="block relative overflow-hidden">
                <div className="aspect-[16/10] overflow-hidden bg-gray-100">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
              </a>
              
              <div className="mt-8">
                <div className="flex justify-between items-baseline mb-4">
                  <h3 className="text-2xl font-light text-gray-900">
                    {project.title}
                  </h3>
                  <span className="text-sm text-gray-500 font-light">
                    {project.year}
                  </span>
                </div>
                
                <p className="text-gray-600 font-light mb-3">
                  {project.description}
                </p>
                
                <div className="flex items-center text-sm text-gray-500 font-light">
                  <span>{project.location}</span>
                  <span className="mx-2">•</span>
                  <span>{project.area}</span>
                </div>
                
                <a 
                  href="#" 
                  className="mt-6 inline-flex items-center text-sm text-gray-900 font-light group/link"
                >
                  {t('portfolio.viewProject')}
                  <ArrowRight className="ml-2 w-4 h-4 transition-transform group-hover/link:translate-x-1" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}