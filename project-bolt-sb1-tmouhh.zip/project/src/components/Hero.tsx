import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { ArrowDown } from 'lucide-react';

export default function Hero() {
  const { t } = useLanguage();

  return (
    <div id="home" className="relative h-screen">
      <div className="absolute inset-0">
        <img
          src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80"
          alt="Modern interior with furniture"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50"></div>
      </div>
      
      <div className="relative h-full flex flex-col">
        <div className="flex-1 flex items-center justify-center px-4 pt-32">
          <div className="text-center max-w-4xl">
            <h1 className="text-3xl sm:text-4xl md:text-5xl font-light text-white mb-8 tracking-wide leading-relaxed">
              {t('hero.title')}
            </h1>
            <p className="text-lg sm:text-xl text-gray-200 mb-12 max-w-2xl mx-auto font-light tracking-wide leading-relaxed">
              {t('hero.subtitle')}
            </p>
            <a
              href="#contact"
              className="relative inline-flex items-center justify-center px-6 py-2.5 text-lg font-light tracking-wide text-white bg-transparent group hover:transform hover:translate-y-[-1px] hover:translate-x-[-1px] transition-all duration-300"
              style={{
                border: '1px solid #000',
                boxShadow: `
                  1px 1px 0 #000,
                  2px 2px 0 #FFD700,
                  3px 3px 0 #000,
                  4px 4px 0 rgba(255, 215, 0, 0.5)
                `
              }}
            >
              <span className="relative z-10">{t('hero.cta')}</span>
            </a>
          </div>
        </div>
        
        <div className="pb-12 flex justify-center">
          <a
            href="#portfolio"
            className="animate-bounce text-white hover:text-yellow-400 transition-colors duration-300"
          >
            <ArrowDown className="w-8 h-8" />
          </a>
        </div>
      </div>
    </div>
  );
}