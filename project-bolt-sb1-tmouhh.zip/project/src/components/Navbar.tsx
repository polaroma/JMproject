import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import LanguageSwitcher from './LanguageSwitcher';

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      isScrolled ? 'bg-white/95 backdrop-blur-sm shadow-lg' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-24">
          {/* Logo */}
          <a href="#home" className="relative group">
            <div className="flex items-center">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <span className="text-5xl font-bold tracking-tight text-gray-900 transition-all duration-300 group-hover:translate-y-[-2px] group-hover:translate-x-[-2px] inline-block transform" 
                    style={{ 
                      textShadow: `
                        1px 1px 0px #000,
                        2px 2px 0px #FFD700,
                        3px 3px 0px #000,
                        4px 4px 0px rgba(255,215,0,0.5),
                        6px 6px 0px rgba(0,0,0,0.2),
                        8px 8px 15px rgba(0,0,0,0.2)
                      `
                    }}>
                    J
                  </span>
                </div>
                <span className="text-5xl font-extralight tracking-tight text-gray-800/70 transition-all duration-300 group-hover:translate-y-[-1px] group-hover:translate-x-[-1px] inline-block transform" 
                  style={{ 
                    textShadow: `
                      1px 1px 0px rgba(0,0,0,0.3),
                      2px 2px 0px rgba(255,215,0,0.3),
                      3px 3px 10px rgba(0,0,0,0.1)
                    `
                  }}>
                  &
                </span>
                <div className="relative">
                  <span className="text-5xl font-bold tracking-tight text-gray-900 transition-all duration-300 group-hover:translate-y-[-2px] group-hover:translate-x-[-2px] inline-block transform" 
                    style={{ 
                      textShadow: `
                        1px 1px 0px #000,
                        2px 2px 0px #FFD700,
                        3px 3px 0px #000,
                        4px 4px 0px rgba(255,215,0,0.5),
                        6px 6px 0px rgba(0,0,0,0.2),
                        8px 8px 15px rgba(0,0,0,0.2)
                      `
                    }}>
                    M
                  </span>
                </div>
                <div className="relative pl-3">
                  <span className="text-base font-light tracking-[0.2em] uppercase text-gray-800/70 transition-all duration-300 group-hover:translate-y-[-1px] group-hover:translate-x-[-1px] inline-block transform" 
                    style={{ 
                      textShadow: `
                        1px 1px 0px rgba(0,0,0,0.2),
                        2px 2px 0px rgba(255,215,0,0.2),
                        3px 3px 5px rgba(0,0,0,0.1)
                      `
                    }}>
                    project
                  </span>
                </div>
              </div>
            </div>
            
            {/* Hover effect underline */}
            <div className="absolute -bottom-1 left-0 w-0 h-px bg-yellow-400 group-hover:w-full transition-all duration-500" />
          </a>

          {/* Desktop Navigation */}
          <div className="hidden md:flex md:items-center md:space-x-8">
            <div className="flex items-center space-x-8">
              {['home', 'about', 'portfolio', 'services', 'contact'].map((item) => (
                <a
                  key={item}
                  href={`#${item}`}
                  className={`relative px-3 py-2 text-sm font-light tracking-wide transition-colors duration-300 ${
                    isScrolled
                      ? 'text-gray-900 hover:text-yellow-400'
                      : 'text-white hover:text-yellow-400'
                  } group`}
                >
                  {t(`nav.${item}`)}
                  <span className="absolute bottom-0 left-0 w-0 h-px bg-yellow-400 group-hover:w-full transition-all duration-300" />
                </a>
              ))}
            </div>
            <LanguageSwitcher isScrolled={isScrolled} />
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className={`p-2 transition-colors duration-300 ${
                isScrolled ? 'text-gray-900' : 'text-white'
              }`}
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 bg-white/95 backdrop-blur-sm shadow-lg">
          <div className="px-4 pt-2 pb-3 space-y-1">
            {['home', 'about', 'portfolio', 'services', 'contact'].map((item) => (
              <a
                key={item}
                href={`#${item}`}
                className="block px-3 py-2 text-base font-light text-gray-900 hover:text-yellow-400 tracking-wide"
                onClick={() => setIsOpen(false)}
              >
                {t(`nav.${item}`)}
              </a>
            ))}
            <div className="px-3 py-2">
              <LanguageSwitcher isScrolled={true} />
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}