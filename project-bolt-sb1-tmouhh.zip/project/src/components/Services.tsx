import React from 'react';
import { Paintbrush, Building2, Sofa, Camera } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Services() {
  const { t } = useLanguage();

  const services = [
    {
      icon: Paintbrush,
      title: t('services.interior'),
      description: t('services.interior.desc'),
    },
    {
      icon: Building2,
      title: t('services.commercial'),
      description: t('services.commercial.desc'),
    },
    {
      icon: Sofa,
      title: t('services.furniture'),
      description: t('services.furniture.desc'),
    },
    {
      icon: Camera,
      title: t('services.visualization'),
      description: t('services.visualization.desc'),
    },
  ];

  return (
    <section id="services" className="py-32 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-3xl font-light text-gray-900 sm:text-4xl tracking-wide">
            {t('services.title')}
          </h2>
          <p className="mt-6 text-lg text-gray-600 font-light tracking-wide max-w-2xl mx-auto">
            {t('services.subtitle')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div key={index} className="group">
                <div className="aspect-square bg-white rounded-none p-12 flex flex-col items-center justify-center text-center transition-all duration-300 hover:shadow-2xl">
                  <Icon className="h-12 w-12 text-gray-900 mb-6 transition-transform duration-300 group-hover:scale-110" />
                  <h3 className="text-xl font-light text-gray-900 mb-4 tracking-wide">{service.title}</h3>
                  <p className="text-gray-600 font-light tracking-wide leading-relaxed">{service.description}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}