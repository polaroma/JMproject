import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';

interface LanguageSwitcherProps {
  isScrolled?: boolean;
}

export default function LanguageSwitcher({ isScrolled = false }: LanguageSwitcherProps) {
  const { language, setLanguage } = useLanguage();

  return (
    <div className="flex items-center space-x-2">
      <button
        onClick={() => setLanguage('pl')}
        className={`px-2 py-1 text-sm font-light tracking-wide transition-colors duration-300 ${
          language === 'pl'
            ? 'text-yellow-400'
            : isScrolled
            ? 'text-gray-900 hover:text-yellow-400'
            : 'text-white hover:text-yellow-400'
        }`}
      >
        PL
      </button>
      <span className={`text-sm ${
        isScrolled ? 'text-gray-900' : 'text-white'
      }`}>/</span>
      <button
        onClick={() => setLanguage('en')}
        className={`px-2 py-1 text-sm font-light tracking-wide transition-colors duration-300 ${
          language === 'en'
            ? 'text-yellow-400'
            : isScrolled
            ? 'text-gray-900 hover:text-yellow-400'
            : 'text-white hover:text-yellow-400'
        }`}
      >
        EN
      </button>
    </div>
  );
}