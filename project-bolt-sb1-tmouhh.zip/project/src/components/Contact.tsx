import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function Contact() {
  const { t } = useLanguage();

  return (
    <section id="contact" className="py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-3xl font-light text-gray-900 sm:text-4xl tracking-wide">
            {t('contact.title')}
          </h2>
          <p className="mt-6 text-lg text-gray-600 font-light tracking-wide max-w-2xl mx-auto">
            {t('contact.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          <div>
            <form className="space-y-8">
              <div>
                <label htmlFor="name" className="block text-sm font-light text-gray-600 tracking-wide mb-2">
                  {t('contact.name')}
                </label>
                <input
                  type="text"
                  id="name"
                  className="w-full border-b border-gray-200 py-3 focus:border-gray-900 focus:outline-none font-light"
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-light text-gray-600 tracking-wide mb-2">
                  {t('contact.email')}
                </label>
                <input
                  type="email"
                  id="email"
                  className="w-full border-b border-gray-200 py-3 focus:border-gray-900 focus:outline-none font-light"
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-light text-gray-600 tracking-wide mb-2">
                  {t('contact.message')}
                </label>
                <textarea
                  id="message"
                  rows={4}
                  className="w-full border-b border-gray-200 py-3 focus:border-gray-900 focus:outline-none font-light"
                ></textarea>
              </div>
              
              <button
                type="submit"
                className="w-full bg-gray-900 text-white px-8 py-4 font-light tracking-wide hover:bg-gray-800 transition-colors duration-300"
              >
                {t('contact.submit')}
              </button>
            </form>
          </div>
          
          <div className="space-y-12">
            <div className="flex items-start">
              <Phone className="h-6 w-6 text-gray-900 mt-1" />
              <div className="ml-8">
                <h3 className="text-lg font-light text-gray-900 tracking-wide">{t('contact.phone')}</h3>
                <p className="mt-2 text-gray-600 font-light tracking-wide">+48 514 540 623</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <Mail className="h-6 w-6 text-gray-900 mt-1" />
              <div className="ml-8">
                <h3 className="text-lg font-light text-gray-900 tracking-wide">{t('contact.email')}</h3>
                <p className="mt-2 text-gray-600 font-light tracking-wide">biuro.jmproject@gmail.com</p>
              </div>
            </div>
            
            <div className="flex items-start">
              <MapPin className="h-6 w-6 text-gray-900 mt-1" />
              <div className="ml-8">
                <h3 className="text-lg font-light text-gray-900 tracking-wide">{t('contact.address')}</h3>
                <p className="mt-2 text-gray-600 font-light tracking-wide">
                  {t('contact.area')}<br />
                  {t('contact.remote')}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}