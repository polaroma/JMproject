/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Josefin Sans', 'system-ui', 'sans-serif'],
      },
      colors: {
        brand: {
          yellow: '#FFD700',
          gray: '#808080',
        },
      },
    },
  },
  plugins: [],
};